#include "NRL.h"

// ---- Tune these on the robot ----
#define CLAW_BTN       BTN_LB     // left button: hold = claw closed
#define AUX_BTN        BTN_RB     // right button: tap = servo 3 toggles
static const float CLAW_OPEN   = 40.0f;   // swap with CLOSED if it moves the wrong way
static const float CLAW_CLOSED = 120.0f;
static const float AUX_OFF     = 0.0f;    // servo 3 resting angle
static const float AUX_ON      = 90.0f;   // servo 3 angle after a tap
static const float ARM_MIN     = 0.0f;
static const float ARM_MAX     = 180.0f;
static const float ARM_SPEED   = 1.2f;    // degrees per tick at full stick
static const float ARM_DIR     = 1.0f;    // set to -1.0f if stick up lowers the arm
static const float ARM_DIAG    = 0.4f;    // lower = diagonals count as up/down more easily
static const float DEADZONE    = 0.08f;

static const float DRIVE_SCALE = 0.55f;   // top speed, 0.0 to 1.0 (lower = slower)
static const float TURN_SCALE  = 0.6f;    // how hard turning is, 0.0 to 1.0 (lower = slower)
static const float RAMP_RATE   = 0.03f;   // acceleration per tick (lower = smoother)

// ---- Hardware ----
static HexaDCMotor leftMotor {{ .dirPin = MOTOR_L_DIR, .pwmPin = MOTOR_L_PWM }};
static HexaDCMotor rightMotor{{ .dirPin = MOTOR_R_DIR, .pwmPin = MOTOR_R_PWM, .flipped = true }};
static HexaServo   arm       {{ .signalPin = SERVO_1, .startAngle = 90.0f }};
static HexaServo   claw      {{ .signalPin = SERVO_2, .startAngle = CLAW_OPEN }};
static HexaServo   aux       {{ .signalPin = SERVO_3, .startAngle = AUX_OFF }};
static TankDrive   drive(leftMotor, rightMotor);

static float dz(float v) { return fabsf(v) < DEADZONE ? 0.0f : v; }

// Squares the stick value (keeps the sign) so small pushes move slowly
static float curve(float v) { return v * fabsf(v); }

class DriveTeleOp : public NRLOpMode {
public:
    void init() override {
        drive.setScale(DRIVE_SCALE);
        drive.setRampRate(RAMP_RATE);

        leftMotor.begin();
        rightMotor.begin();
        arm.begin();
        claw.begin();
        aux.begin();
        armAngle = 90.0f;
        clawClosed = false;
        auxOn = false;
        prevAuxBtn = false;
        claw.setPosition(CLAW_OPEN);
        aux.setPosition(AUX_OFF);
    }

    void loop() override {
        // Connection lost: stop the wheels, but leave the arm, claw and servo 3
        // exactly where they are. Nothing below runs until packets come back,
        // so the claw can't pop open (zeroed buttons) and then snap shut again.
        if (NRLComms::isInputStale()) {
            drive.drive(0.0f, 0.0f);
            return;
        }

        // Left stick: forward/back plus turn at the same time.
        // Up-right = forward AND right, up-left = forward AND left, etc.
        float f = -curve(dz(gamepad1.leftY()));
        float t =  curve(dz(gamepad1.leftX())) * TURN_SCALE;
        float m = fmaxf(fabsf(f) + fabsf(t), 1.0f);   // keep the mix from clipping,
        drive.drive(f / m, t / m);                    // so the diagonal ratio is preserved

        // Right stick: the whole upper half raises the arm (up, up-left, up-right),
        // the whole lower half lowers it (down, down-left, down-right).
        // Pure left/right does nothing. Holds position when released.
        float rx = gamepad1.rightX();
        float ry = gamepad1.rightY();
        float mag = fminf(sqrtf(rx * rx + ry * ry), 1.0f);
        if (mag > DEADZONE && fabsf(ry) >= ARM_DIAG * fabsf(rx)) {
            float dir = (ry > 0.0f) ? 1.0f : -1.0f;
            armAngle += dir * mag * ARM_SPEED * ARM_DIR;
            armAngle = constrain(armAngle, ARM_MIN, ARM_MAX);
        }
        arm.setPosition(armAngle);

        // Left button: hold = claw closed, release = open
        bool wantClosed = gamepad1.pressed(CLAW_BTN);
        if (wantClosed != clawClosed) {
            clawClosed = wantClosed;
            claw.setPosition(clawClosed ? CLAW_CLOSED : CLAW_OPEN);
        }

        // Right button: each tap flips servo 3 between 0 and 90
        bool auxBtn = gamepad1.pressed(AUX_BTN);
        if (auxBtn && !prevAuxBtn) {
            auxOn = !auxOn;
            aux.setPosition(auxOn ? AUX_ON : AUX_OFF);
        }
        prevAuxBtn = auxBtn;
    }

    void stop() override {
        drive.stop();
    }

private:
    float armAngle   = 90.0f;
    bool  clawClosed = false;
    bool  auxOn      = false;
    bool  prevAuxBtn = false;
};

REGISTER_OPMODE(DriveTeleOp, "Drive TeleOp", TELEOP);
#include "NRL.h"

// ---- Hardware ----
static HexaDCMotor leftMotor {{ .dirPin = MOTOR_L_DIR, .pwmPin = MOTOR_L_PWM }};
static HexaDCMotor rightMotor{{ .dirPin = MOTOR_R_DIR, .pwmPin = MOTOR_R_PWM, .flipped = true }};
static HexaServo   arm       {{ .signalPin = SERVO_1, .startAngle = 90.0f }};
static HexaServo   claw      {{ .signalPin = SERVO_2, .startAngle = 0.0f  }};
static TankDrive   drive(leftMotor, rightMotor);

// ---- Tune these on the robot ----
#define CLAW_BTN     BTN_RB     // right button: hold = claw closed
static const float CLAW_OPEN   = 0.0f;    // swap with CLOSED if it moves the wrong way
static const float CLAW_CLOSED = 90.0f;
static const float ARM_MIN     = 0.0f;
static const float ARM_MAX     = 180.0f;
static const float ARM_SPEED   = 1.2f;    // degrees per tick at full stick
static const float ARM_DIR     = 1.0f;    // set to -1.0f if stick up lowers the arm
static const float DEADZONE    = 0.08f;

static float dz(float v) { return fabsf(v) < DEADZONE ? 0.0f : v; }

class DriveTeleOp : public NRLOpMode {
public:
    void init() override {
        leftMotor.begin();
        rightMotor.begin();
        arm.begin();
        claw.begin();
        armAngle = 90.0f;
        clawClosed = false;
        claw.setPosition(CLAW_OPEN);
    }

    void loop() override {
        // Left stick: drive and turn
        drive.drive(dz(gamepad1.leftY()), dz(gamepad1.leftX()));

        // Right stick: up raises arm, down lowers it (holds when released)
        armAngle += dz(gamepad1.rightY()) * ARM_SPEED * ARM_DIR;
        armAngle = constrain(armAngle, ARM_MIN, ARM_MAX);
        arm.setPosition(armAngle);

        // Right button: hold = closed, release = open
        bool wantClosed = gamepad1.pressed(CLAW_BTN);
        if (wantClosed != clawClosed) {
            clawClosed = wantClosed;
            claw.setPosition(clawClosed ? CLAW_CLOSED : CLAW_OPEN);
        }
    }

    void stop() override {
        drive.stop();
    }

private:
    float armAngle   = 90.0f;
    bool  clawClosed = false;
};

REGISTER_OPMODE(DriveTeleOp, "Drive TeleOp", TELEOP);